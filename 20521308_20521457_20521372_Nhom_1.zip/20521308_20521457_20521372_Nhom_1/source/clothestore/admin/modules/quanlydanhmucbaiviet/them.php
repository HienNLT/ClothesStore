
	<div class="col-md-12" style="margin-bottom: 20px;">
<h3 style="margin-top:40px">Quản lý danh mục bài viết</h3>
<div style="float: left;" class="col-md-6">
 <form method="POST" action="modules/quanlydanhmucbaiviet/xuly.php">
 <div class="form-group">
<label for="usr" style="font-weight: bold;">Tên Danh Mục Bài Viết:</label>
<input  type="text" class="form-control" id="usr" name="tendanhmucbaiviet" >
<label for="usr" style="font-weight: bold;">Thứ tự:</label>
  <input  type="text" class="form-control" id="usr" name="thutu" >
  </div>
  <button type="submit"name="themdanhmucbaiviet" class="btn btn-success">Lưu</button>
</tr>
</form>
</div> 



