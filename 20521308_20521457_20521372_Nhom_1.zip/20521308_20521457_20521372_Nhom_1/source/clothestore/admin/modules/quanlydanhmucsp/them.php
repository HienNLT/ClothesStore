<div class="row" style="margin-top: 20px;">
<div class="col-md-12" style="margin-bottom: 20px;">
<h3 style="margin-top:40px">Quản lý danh mục sản phẩm</h3>
<div style="float: left;" class="col-md-6">
<form method="POST" action="modules/quanlydanhmucsp/xuly.php">
<div class="form-group">
<label for="usr" style="font-weight: bold;">Tên Danh Mục:</label>
  <input  type="text" class="form-control" id="usr" name="tendanhmuc" >
  <label for="usr" style="font-weight: bold;">Thứ tự:</label>
  <input  type="text" class="form-control" id="usr" name="thutu" >
	</div>
  <button type="submit"name="themdanhmuc" class="btn btn-success">Lưu</button>
</tr>
</form>
</div>